package com.example.listviewdemo;
import android.app.Application;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;



import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter{

    ArrayList<RepositoryVO> repositoryVOList;
    Context context;

    LayoutInflater layoutInflater;



    public ListViewAdapter(ArrayList<RepositoryVO> repositoryVOList, Application application) {

    }

    @Override
    public int getCount() {

            return repositoryVOList.size();


    }

    @Override
    public Object getItem(int position) {
        return repositoryVOList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(layoutInflater == null)
        {
            layoutInflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if(convertView == null)
        {
            convertView = layoutInflater.inflate(R.layout.customlayout,parent,false);
        }

        TextView RepositoryName = convertView.findViewById(R.id.txtv_p);
        TextView OwnerName = convertView.findViewById(R.id.textView);


        RepositoryName.setText(repositoryVOList.get(position).getName());
        OwnerName.setText(repositoryVOList.get(position).getOwnerVO().getLogin());

        return convertView;
    }
}
